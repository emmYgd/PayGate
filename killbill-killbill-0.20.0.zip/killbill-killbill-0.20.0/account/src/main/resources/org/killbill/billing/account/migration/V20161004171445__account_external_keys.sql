alter table accounts modify external_key varchar(255);
alter table account_history modify external_key varchar(255);