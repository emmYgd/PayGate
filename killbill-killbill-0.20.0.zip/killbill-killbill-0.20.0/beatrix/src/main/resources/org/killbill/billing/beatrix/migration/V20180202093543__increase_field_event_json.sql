alter table bus_ext_events modify event_json text not null;
alter table bus_ext_events_history modify event_json text not null;
